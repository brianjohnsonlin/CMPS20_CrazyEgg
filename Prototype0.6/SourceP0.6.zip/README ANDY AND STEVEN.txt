Most of the work I did was in entities.js and the TMX maps.
The main menu stuff should happen in another js file, so I think it would be easy to merge.
The only thing that would be more difficult to merge is the resources, but if you add resources below all the files already there, we could distinguish what you added vs what I added.
Also, keep track of what is added and changed so we don't spend 13957539 years figuring out how to merge.

Thanks!
Brian